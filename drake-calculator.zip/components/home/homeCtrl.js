app.controller('homeCtrl', ['$scope','drakeCalculator', homeCtrl]);

function homeCtrl($scope, drakeCalculator) {
  $scope.r = 0;
  $scope.$watchCollection('[r]', function(newValues){
    console.log(drakeCalculator.n(1,1,1,1,1,1,1))
  });
}